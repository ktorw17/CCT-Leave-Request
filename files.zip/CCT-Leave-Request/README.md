# CCT Leave Request

ระบบลางานภายในบริษัทขนาดเล็ก (<20 คน)

- Backend: Node.js + Express
- Frontend: React + Vite
- รองรับสองภาษา: ไทย/อังกฤษ

🔹 วิธีสร้าง ZIP เอง

สร้างโฟลเดอร์ CCT-Leave-Request

สร้างโฟลเดอร์ backend และ frontend ตามตัวอย่าง

วางไฟล์ที่ให้ด้านบนลงในโฟลเดอร์ที่ถูกต้อง

คลิกขวาที่โฟลเดอร์ CCT-Leave-Request → Send to → Compressed (zipped) folder (Windows) หรือ Compress (Mac)

จะได้ไฟล์ CCT-Leave-Request.zip พร้อมอัปโหลด GitHub